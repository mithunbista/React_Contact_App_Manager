const Constants = {
   "LOCAL_STORAGE_KEY": "contacts",
   "ContactExists" : "Contact already exist!",
   "AllFieldsMandatory" : "All the fields are mandatory!",
   "DeleteRecords": "Are you sure you want to delete this record?"                               
}

export default Constants;